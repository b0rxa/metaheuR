library(testthat)
library(metaheuR)

test_check("metaheuR")
