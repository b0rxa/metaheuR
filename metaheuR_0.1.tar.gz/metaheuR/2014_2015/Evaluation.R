library(igraph)
library(metaheuR)
library(scmamp)

plot.comm <- function(graph , solution) community.detection.problem(graph)$plot(solution)


graph.dir <- "/home/aitatxoborja/02_Teaching/Gradoak/Bilaketa heuristikoak/Sare_sozialak/Data/Ikasleentzat/community_detection/Community_detection_grafoak"
res.dir <- "/home/aitatxoborja/02_Teaching/Gradoak/Bilaketa heuristikoak/Sare_sozialak"
file.list <- list.files(graph.dir)[grep(".csv" , list.files(graph.dir))]

make.connected <- function (graph){
  ## Identify disconnected nodes and link them with a random node
  if (!is.connected(graph)){
    dg <-degree(graph)
    n <- length(V(graph))
    set <- 1:n
    list.disc <- which(dg==0)
    if (length(list.disc)!=0){
      to.add <- lapply (list.disc , FUN=function(x) c(x , sample(subset(set,set!=x) , 1)))
      trh <- lapply(to.add , FUN = function(x) graph <<- add.edges(graph , x))
    }
  }
  
  ##Now, for each two connected components, select two random nodes and link them
  if (!is.connected(graph)){
    conncomp <- clusters(graph)
    for (i in 2:conncomp$no){
      n1 <- sample(which(conncomp$membership == i-1) , 1)
      n2 <- sample(which(conncomp$membership == i) , 1)
      graph <- add.edges(graph , c(n1,n2))
    }
  }
  
  graph
}


## Use the spinglass.community algorithm, the only one that allows determining the number of communities
community_detection <- function (file , k){
  cat(paste("Processing file " , which(file.list %in% file) , " out of " , length(file.list), "\n" , sep="" ))
  g <- load.graph (paste(graph.dir , file , sep="/"))
  ## We need a connected graph to run the algorithm
  aux.g <- make.connected(g)
  sol <- spinglass.community(aux.g , spins = k)$membership
  ## The solution has to be evaluated using the original graph
  eval <- community.detection.problem(g)$evaluate(sol)
  -eval
}

evaluate_solutions <- function(file){
  g <- load.graph (paste(graph.dir , file , sep="/"))
  n <- length(V(g))
  c2 <- floor(n/2)
  c3 <- floor(n/3)
  sol_2k <- c(rep(1,c2) , rep(2,n-c2))
  sol_3k <- c(rep(1,c3) , rep(2,c3) , rep(3,n-(2*c3)))
  e2k <- -1 * community.detection.problem(g)$evaluate(sol_2k)
  e3k <- -1 * community.detection.problem(g)$evaluate(sol_3k)
  data.frame(Set=file , E2k=e2k , E3k=e3k)
}


res <- lapply (file.list , FUN = function(x) evaluate_solutions(x))
mat <- do.call(rbind,res)

res <- lapply (file.list , FUN = function(x) data.frame(x , community_detection(x , k=3), community_detection(x , k=5), community_detection(x , k=10)))
mat <- do.call(rbind,res)
colnames(mat) <- c("Graph" , "Modularity, K=3", "Modularity, K=5","Modularity, K=10")
save(mat , file=paste(res.dir , "modularity_best_solutions.Rdata" , sep="/"))

write.tabular(mat , file = "/home/aitatxoborja/kk.tex" , format = 'f' , align = 'l' , hrule = 0 , vrule=1 , print.row.names = F)


# Testing the implementations ---------------------------------------------
n <- 25
k <- 3

difficulty <- 2
scale <-1
pintra<-c(2500,5000)/n^2
pinter<-pintra*difficulty/100
pf<-matrix(runif(k^2,pinter[1],pinter[2]),ncol=k)
pf[cbind(1:k,1:k)]<-runif(k,pintra[1],pintra[2])


pf <- pf*scale

pf <- pf/max(pf*1.1)

g<-preference.game(nodes = n*k, types = k, pref.matrix=pf)
plot(g,vertex.size=5)


comm.problem <- community.detection.problem(g)
commnunities <- paste("K",1:k,sep="")


random.solution <- function(size, communities){
  factor (sample(commnunities , size = size , replace = TRUE) , levels=commnunities)
}

init.sol <- random.solution(n*k , communities) 

system.time({ngh <- hammingNeighborhood(base = init.sol, random = TRUE)
bls <- basic.local.search(evaluate = comm.problem$evaluate , initial.solution = init.sol, neighborhood = ngh , selector = first.improvement.selector)})

comm.problem$plot(optima(bls)[[1]])

sol<-walktrap.community(graph = g)$membership
comm.problem$evaluate(sol)


comm.problem$plot(sol$membership)

