
## Function to load graphs from plain text files. The first row containts a number indicating the number of nodes
## The rest of the rows have pairs of numbers indicating the edges in the graph
load.graph<-function(file.path){
  conn<-file(file.path,"ro")
  numnodes<-as.numeric(readLines(conn,n = 1))
  edges<-readLines(conn, n=-1L)
  ## Create an empty graph
  graph<-graph.empty(n = numnodes,directed = F)
  
  ## Set the edges
  lapply(strsplit(edges," "), FUN = function(x){graph[x[1],x[2]]<<-1})
  
  close(conn)
  graph
}


#' Community detection problem
#' 
#' This function generates an evaluation and plotting function for the community detection problem
#' @concept Optimization_problems
#' @param graph Graph where the community structure will be searched.
#' @return A list of functions to be used to solve a community detection problem. This includes the functions \code{evaluate}, for the evaluation of a solution and \code{plot} to graphically show the solution; all the functions have a single argument,  \code{solution}, representing the solution considered. The solutions have to be vectors of factors indicating the community to which each node belongs

community.detection.problem<-function(graph){
  
  if (!require(igraph))
    stop("The 'igraph' package is required, you can install it typing 'install.packages('igraph')")
  
  ## The goal is maximizing the modularity and, thus, we have to multiply it by -1
  evaluate <- function(solution){
    -1*modularity(graph, solution)
  }
  
  plot.solution <- function (solution , node.size = 5 , label.cex = 0.5){
    if(!require(colorspace))
      stop("The 'colorspace' package is required. You can install it typing 'install.packages('colorspace')'")
    values <- unique(as.numeric(solution))
    num.colors <- length(values)
    palette <- rainbow_hcl(num.colors, c = 50, l = 70, start = 0, end = 360*(num.colors-1)/num.colors)
    colors <- as.numeric(solution)
    for (i in 1:num.colors) colors[colors==values[i]] <- palette[i]
    V(graph)$color <- colors
    V(graph)$label <- solution
    plot.igraph(graph , vertex.size = node.size , edge.arrow.mode="-" , 
                vertex.label.color = "white" , vertex.label.family = "sans" , 
                vertex.label.cex = label.cex)
  }
  
  return(list(evaluate = evaluate , plot = plot.solution))
}


#' Spread of Influence problem
#' 
#' 
#' @param 
#' @return A list of functions to be used to solve a Spread of Influence problem. This includes the functions \code{evaluate}, for the evaluation of a solution, \code{is.valid}, to check whetehr a solution is valid or not, \code{correct}, to correct a non-valid solution and \code{plot} to graphically show the solution; all the functions have a single argument,  \code{solution}. The solutions passed to these functions has to be a logical vector indicating with \code{TRUE} which nodes are in the independent set.

SoI.problem <- function (graph){

  evaluate <- function (solution){
    NULL
  }
  
  is.valid <- function (solution){
    NULL
  }
  
  correct <- function (solution){
    NULL
  }
  
  plot.solution <- function (solution, node.size = 5){
    NULL
  }
  
  return(list(evaluate = evaluate , is.valid = is.valid , correct = correct , plot = plot.solution))
}