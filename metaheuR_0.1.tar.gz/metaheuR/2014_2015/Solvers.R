library(metaheuR)
library(igraph)
source("./2014_2015/problemak.R")

graph.dir <- "/home/aitatxoborja/02_Teaching/Gradoak/Bilaketa heuristikoak/Sare_sozialak/Data/Ikasleentzat/community_detection/Community_detection_grafoak/"

file.list <- list.files(graph.dir)

run.community.detection <- function (file.path , time = 60 , k=5){
  g <- load.graph(file.path)
  pr <- community.detection.problem(graph = g)
  
  n <- length(V(g))
  
  crs <- cresource(time = time)
  rnd.sol.generator <- function (...) factor(sample(1:k , size = n , replace = TRUE) , 1:k )
  
  
  args <- list()
  args$evaluate           <- pr$evaluate
  args$initial.solution   <- rnd.sol.generator()
  args$neighborhood       <- hammingNeighborhood(args$initial.solution , random = FALSE)
  args$selector           <- first.improvement.selector
  args$resources          <- crs
  args$generate.solution  <- rnd.sol.generator
  
  ## Basic local search
  bls <- do.call(basic.local.search , args)
  
  ## Iterated local search
  args$perturb <- factor.mutation
  args$ratio <- 0.33
  
  ils <- do.call(iterated.local.search , args)
  
#   pop.size <- 10*n
#   args$initial.population   <- lapply(1:pop.size , function(i) rnd.sol.generator())
#   args$learn                <- univariateMarginals
#   args$select.subpopulation <- tournament.selection
#   args$selection.ratio         <- 0.66
#   args$use.rankings         <- TRUE
#   eda <- do.call(basic.eda , args)
  list(LS = evaluation(bls) , ILS = evaluation(ils))
}

file.path <- paste(graph.dir , file.list[100] , sep="/")
run.community.detection(file.path , time = 5 , k=3)

files <- file.list[(grep("rep_9" , file.list))]
time <- 60
communities <- 5
results <- data.frame()
for (f in files){
  pth <- paste(graph.dir , f , sep="/")
  cat("Running experimentation in file" , f , "\n")
  cat("++++++++++++++++++++++++++++++++++++++++++\n")
  r <- run.community.detection(pth , time = time , k = communities)
  results <- rbind (results , data.frame("Graph" = f , "LS" = r$LS , "ILS" = r$ILS))
}
